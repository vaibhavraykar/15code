import { Component } from '@angular/core';

@Component({
  selector: 'app-rm-management',
  templateUrl: './rm-management.component.html',
  styleUrls: ['./rm-management.component.scss']
})
export class RmManagementComponent {

}
