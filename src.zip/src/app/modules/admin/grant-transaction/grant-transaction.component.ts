import { Component } from '@angular/core';

@Component({
  selector: 'app-grant-transaction',
  templateUrl: './grant-transaction.component.html',
  styleUrls: ['./grant-transaction.component.scss']
})
export class GrantTransactionComponent {

}
