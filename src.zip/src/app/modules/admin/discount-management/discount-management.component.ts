import { Component } from '@angular/core';

@Component({
  selector: 'app-discount-management',
  templateUrl:'./discount-management.component.html',
  styleUrls: ['./discount-management.component.scss']
})
export class DiscountManagementComponent {

}
