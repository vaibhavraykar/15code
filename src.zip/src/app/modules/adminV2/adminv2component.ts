import { Component } from '@angular/core';

@Component({
  selector: 'app-adminv2',
  templateUrl: './adminv2.component.html',
  styleUrls: ['./adminv2.component.scss']
})
export class AdminV2Component {

}
